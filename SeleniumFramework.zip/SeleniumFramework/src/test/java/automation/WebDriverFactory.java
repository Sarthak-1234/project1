/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package automation;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import automation.getpageobjects.Browsers;

public class WebDriverFactory {

	private static String browser, seleniumServer;
	private static String chromeDriverPath = "src/test/resources/drivers/chromedriver";
	private static String iEDriverPath = "src/test/resources/drivers/IEDriverServer" ;
	private static DesiredCapabilities capabilities = new DesiredCapabilities();
	private static String firefoxProfilePath = "C:/selenium/FirefoxProfile";

	public WebDriver getDriver(Map<String, String> seleniumconfig) {
		browser = System.getProperty("browser");
		seleniumServer =System.getProperty("seleniumServer");
		if (browser == null)
			browser = seleniumconfig.get("browser").toString();
		if(seleniumServer==null)
			seleniumServer = seleniumconfig.get("seleniumserver").toString();
        if (seleniumServer.equalsIgnoreCase("remote")) {
        	 return setRemoteDriver(seleniumconfig);
        }else{
        	switch (Browsers.valueOf(browser)) {
           			case firefox:
           			case FIREFOX:
           				return getFirefoxDriver();
			case chrome:
           	case CHROME:
           			if(System.getProperty("os.name").toUpperCase().equals("LINUX")){
           				return getChromeDriver(chromeDriverPath);
           			}
           			else return getChromeDriver(chromeDriverPath+".exe");
			case ie:
           	case IE:
           	case InternetExplorer:
           	case internetexplorer:
           				return getInternetExplorerDriver(iEDriverPath+".exe");
			case Safari:
           	case SAFARI:
           	case safari:
           				return getSafariDriver();
			default:
           				return new FirefoxDriver();
        			}
        	}
     }

    private WebDriver setRemoteDriver(Map<String, String> selConfig) {
        DesiredCapabilities cap = null;
        browser = System.getProperty("browser");
        if(browser==null)
        		browser = selConfig.get("browser").toString();
        if (browser.equalsIgnoreCase("firefox")) {
            cap = DesiredCapabilities.firefox();
        } else if (browser.equalsIgnoreCase("chrome")) {
            cap = DesiredCapabilities.chrome();
        } else if (browser.equalsIgnoreCase("Safari")) {
            cap = DesiredCapabilities.safari();
        } else if ((browser.equalsIgnoreCase("ie"))
                || (browser.equalsIgnoreCase("internetexplorer"))
                || (browser.equalsIgnoreCase("internet explorer"))) {
            cap = DesiredCapabilities.internetExplorer();
        }
        String seleniuhubaddress = System.getProperty("hub");
        if (seleniuhubaddress==null) seleniuhubaddress = selConfig.get("seleniumserverhost1");
        else{
        	if(System.getProperty("hub").equals("hub1"))
        		seleniuhubaddress = selConfig.get("seleniumserverhost1");
        	else if(System.getProperty("hub").equals("hub2"))
        		seleniuhubaddress = selConfig.get("seleniumserverhost2");
        }
        URL selserverhost = null;
        try {
            selserverhost = new URL(seleniuhubaddress);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        cap.setJavascriptEnabled(true);
        return new RemoteWebDriver(selserverhost, cap);
    }

	private static WebDriver getChromeDriver(String driverpath) {
		
		System.setProperty("webdriver.chrome.driver", driverpath);
		capabilities.setJavascriptEnabled(true);
		return new ChromeDriver();
		//return new ChromeDriver(capabilities);
	}

	private static WebDriver getInternetExplorerDriver(String driverpath) {
		System.setProperty("webdriver.ie.driver", driverpath);
		capabilities.setCapability("ignoreZoomSetting", true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		// capabilities.setJavascriptEnabled(true); 
		// capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		return new InternetExplorerDriver(capabilities);
	}

	private static WebDriver getSafariDriver() {
		return new SafariDriver();
	}

	/**
	 * For Techtool We have to set the firefox profile and need AutoAuth xpi
	 * AutoAuth is a firefox add on
	 * @return
	 */
	private static WebDriver getFirefoxDriver() {
		FirefoxProfile profile;
		if(TestSessionInitiator.product.equalsIgnoreCase("techtool")){
			String autoAuthPath  = "src/test/resources/Techtool-testdata/autoauth-2.1-fx+fn.xpi";
			
			// Path of Firefox Profile having 'AutoAuth' extension to it
			File firefoxProfile = new File(firefoxProfilePath);
			profile = new FirefoxProfile(firefoxProfile);
			
			// Path of AutoAuth file i.e., in the project
			File extension = new File(autoAuthPath);
			try{
				profile.addExtension(extension);
			}
			catch(IOException e){	
			}
		}
		else{
			 profile = new FirefoxProfile();
		}
		 profile.setPreference("browser.cache.disk.enable", false);
		 profile.setPreference("dom.max_chrome_script_run_time", 20);
		 profile.setPreference("dom.max_script_run_time", 0);
		 return new FirefoxDriver(profile);
	}
}
