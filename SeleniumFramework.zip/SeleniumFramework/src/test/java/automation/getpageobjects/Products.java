package automation.getpageobjects;

public enum Products {
	selenium, Selenium, SELENIUM;
}
