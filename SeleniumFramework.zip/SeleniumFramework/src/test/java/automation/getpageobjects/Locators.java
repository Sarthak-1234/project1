package automation.getpageobjects;

public enum Locators {
	id, name, classname, xpath, css, linktext, linkText;
}