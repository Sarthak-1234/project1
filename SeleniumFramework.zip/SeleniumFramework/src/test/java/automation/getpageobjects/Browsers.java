package automation.getpageobjects;

public enum Browsers {
	chrome,CHROME,
	IE,ie,InternetExplorer,internetexplorer,
	firefox, FIREFOX,ff,FF,Firefox,
	Safari,SAFARI,safari
}
