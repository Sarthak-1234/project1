/*
 * To change this template, choose Tools | Templates


//To implement the file
 * and open the template in the editor.
 */
package automation;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import static automation.utils.DataReadWrite.getProperty;
import static automation.utils.YamlReader.getYamlValue;
import static automation.utils.YamlReader.setYamlFilePath;

import java.util.HashMap;

import org.testng.Reporter;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import automation.utils.SeleniumWebDriverEventListener;
import automation.utils.TakeScreenshot;
import selenium.functional.keywords.HomePageActions;

public class TestSessionInitiator {

	protected WebDriver driver, originalDriver;
	private WebDriverFactory wdfactory;
	Map<String, Object> chromeOptions = null;
	protected static String product;
	public TakeScreenshot takescreenshot;
	public HomePageActions homepage;
	
	public TestSessionInitiator(String testname) {
		wdfactory = new WebDriverFactory();
		testInitiator(testname);
	}
	
	private void _initPage() {
		homepage = new HomePageActions(driver);
	}
	
	
	private void testInitiator(String testname) {
		setYamlFilePath();
		configureBrowser();
		_initPage();
		takescreenshot = new TakeScreenshot(testname, this.driver);
	}
	
	public WebDriver getDriver() {
		return this.driver;
	}

	protected void configureBrowser() {
		driver = wdfactory.getDriver(_getSessionConfig());
		driver.manage().window().maximize();
		int timeout;
		if(System.getProperty("timeout")!=null)
			timeout = Integer.parseInt(System.getProperty("timeout"));
		else
			timeout = Integer.parseInt(_getSessionConfig().get("timeout"));
		driver.manage().timeouts().implicitlyWait(timeout,TimeUnit.SECONDS);
		originalDriver = driver;
		EventFiringWebDriver efwd = new EventFiringWebDriver(driver);
		SeleniumWebDriverEventListener myListener = new SeleniumWebDriverEventListener(
				driver);
		efwd.register(myListener);
		driver = efwd;
	}

	private static Map<String, String> _getSessionConfig() {
		String[] configKeys = { "tier", "browser", "seleniumserver",
				"seleniumserverhost1", "seleniumserverhost2", "timeout", "debugObjects", "takeScreenshot", "uploadImage"};
		Map<String, String> config = new HashMap<String, String>();
		for (String string : configKeys) {
			config.put(string, getProperty("./Config.properties", string));
			//System.out.println(getProperty("./Config.properties", string));
		}
		return config;
	}

	public static String getEnv() {
		String tier = System.getProperty("env");
		if (tier == null)
			tier = _getSessionConfig().get("tier");
		return tier;
	}

	public String getDebugObjects() {
		return _getSessionConfig().get("debugObjects");
	}

	public String getBrowser() {
		String browser = System.getProperty("browser");
		if (browser == null)
			browser = _getSessionConfig().get("browser");
		return browser;
	}

	public String getUploadScreenshotToFtp() {
		return _getSessionConfig().get("uploadImage");
	}

	public String getTakeScreenshot() {
		return _getSessionConfig().get("takeScreenshot");
	}

	public static String getProduct() {
		if (System.getProperty("Config.properties", "product") != null)
			product = System.getProperty("product");
		return product;
	}

	public void launchApplication() {
		launchApplication(getYamlValue("app_url"));
	}

	public void launchApplication(String applicationpath) {
		Reporter.log("The application url is :- " + applicationpath, true);
		Reporter.log("The test browser is :- " + getBrowser(), true);
		driver.get(applicationpath);
	}

	public void getURL(String url) {
		driver.manage().deleteAllCookies();
		driver.get(url);
	}

	public void closeBrowserSession() {
		driver.quit();
	}

	public void stepStartMessage(String testStepName) {
		Reporter.log(" ", true);
		Reporter.log("***** STARTING TEST STEP:- " + testStepName.toUpperCase()
				+ " *****", true);
		Reporter.log(" ", true);
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void closeWindow() {
		driver.close();
	}

}
