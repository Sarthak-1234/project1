package selenium.functional.tests;
import static automation.utils.YamlReader.getYamlValue;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import automation.TestSessionInitiator;
import selenium.functional.keywords.HomePageActions;


public class HomePage{
	
	TestSessionInitiator test;
	String baseUrl;

	@BeforeClass
	public void Start_Test_Session() {
		test = new TestSessionInitiator(this.getClass().getSimpleName());
		initVars();
		test.launchApplication(baseUrl);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	private void initVars() {
		baseUrl = getYamlValue("baseUrl");
	}
	
	@Test()
	public void Verify_DefaultPage(){
		test.homepage.checkHomePageHeadText("Book Domestic and International flights");
	}
	
	@Test()
	public void VerifyBooking_TillPaymentGatewayPage_GuestUser(){
		Assert.assertEquals(test.homepage.From_Field_isDisplayed(), true);
		
		
	}
}
