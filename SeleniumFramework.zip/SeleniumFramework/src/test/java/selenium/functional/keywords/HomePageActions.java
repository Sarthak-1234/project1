package selenium.functional.keywords;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import automation.getpageobjects.GetPage;

public class HomePageActions extends GetPage{
	
	public HomePageActions(WebDriver driver) {
		super(driver, "HomePage");
		this.driver=driver;
	}
	
	public void checkHomePageHeadText(String heading){
		Assert.assertEquals(tabName(), heading,"assertion not matched");
		logMessage("heading matched"+heading);
		
	}

	public String tabName(){
		wait.hardWait(4);
		return element("homepage_headingtext").getText();
		
	}
	
	public boolean From_Field_isDisplayed(){
		System.out.println(isElementDisplayed("isElementDisplayed"));
		return isElementDisplayed("isElementDisplayed");
	}
	
	
}
